#README 

This folder cntains a trajectory file tj.xyz where the coordinates of a binary mixture are sheared. The tilt factors and the box sizes are in the box.txt file.

