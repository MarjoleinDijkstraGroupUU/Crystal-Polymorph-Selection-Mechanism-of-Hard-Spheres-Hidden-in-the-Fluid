To install Python Scripts on your local python installation run:
python ./setup.py install
from this directory.

To uninstall the package, type:
pip uninstall tcc