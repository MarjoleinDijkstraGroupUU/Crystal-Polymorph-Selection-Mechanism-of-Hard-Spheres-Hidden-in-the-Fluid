mkdir build
cd build
cmake ..
make
#make install
pip install /home/willem/Codes/TCC
