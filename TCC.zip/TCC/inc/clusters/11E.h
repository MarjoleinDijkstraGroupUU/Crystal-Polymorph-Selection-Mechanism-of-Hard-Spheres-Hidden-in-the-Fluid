#ifndef TCC_11E_H
#define TCC_11E_H

void Clusters_Get11E_12D(int i, int j, int sp1, int sp2i, int sp2j);

void Clust_Write_11E();

#endif
