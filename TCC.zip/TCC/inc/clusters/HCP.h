#ifndef TCC_HCP_H
#define TCC_HCP_H

void Clusters_GetHCP();

void Cluster_Write_HCP(int i, int j, int j2, int k);

#endif
