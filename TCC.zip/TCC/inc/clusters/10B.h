#ifndef TCC_10B_H
#define TCC_10B_H

void Clusters_Get10B(int j);

void Cluster_Write_10B(int trial[10]);

#endif
