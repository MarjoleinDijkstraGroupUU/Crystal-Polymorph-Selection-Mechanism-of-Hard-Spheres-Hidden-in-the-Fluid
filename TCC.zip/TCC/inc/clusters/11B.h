#ifndef TCC_11B_H
#define TCC_11B_H

void Clusters_Get11B();

void Cluster_Write_11B(const int *extra_particles, int parent_9B_id);

#endif
