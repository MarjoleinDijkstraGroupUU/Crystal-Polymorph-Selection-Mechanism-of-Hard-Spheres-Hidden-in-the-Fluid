#ifndef TCC_12D_H
#define TCC_12D_H

int Clusters_Get12D(int j, int k, int sp1, int sp2);

void Cluster_Write_12D();

#endif
