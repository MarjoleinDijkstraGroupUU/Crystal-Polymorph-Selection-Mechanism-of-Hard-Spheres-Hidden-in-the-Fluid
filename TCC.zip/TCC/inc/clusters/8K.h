#ifndef TCC_8K_H
#define TCC_8K_H

void Clusters_Get8K();

int is_particle_in_5A_ring(const int *second_5A_cluster, int first_5A_ring_particle, int *cp);

void Cluster_Write_8K();

#endif
