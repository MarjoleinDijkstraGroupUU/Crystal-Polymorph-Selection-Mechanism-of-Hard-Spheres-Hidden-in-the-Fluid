#ifndef TCC_FCC_H
#define TCC_FCC_H

void Clusters_GetFCC();

void Cluster_Write_FCC();

#endif
