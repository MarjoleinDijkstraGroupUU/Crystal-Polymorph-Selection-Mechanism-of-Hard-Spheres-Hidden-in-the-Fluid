#ifndef TCC_12B_H
#define TCC_12B_H

void Clusters_Get12B_13A();

int count_7A_spindle_bonds(int *sj1, int first_7A);

void Clust_Write_12B();

#endif
