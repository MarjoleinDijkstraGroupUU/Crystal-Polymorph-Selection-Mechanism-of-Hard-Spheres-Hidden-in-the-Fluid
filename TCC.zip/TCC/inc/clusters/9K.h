#ifndef TCC_9K_H
#define TCC_9K_H

void Clusters_Get9K();

void Cluster_Write_9k(const int *common_ring_particle_ids, const int *uncommon_ring_particles,
                      const int *uncommon_spindle_particles, int common_spindle_id);

#endif
