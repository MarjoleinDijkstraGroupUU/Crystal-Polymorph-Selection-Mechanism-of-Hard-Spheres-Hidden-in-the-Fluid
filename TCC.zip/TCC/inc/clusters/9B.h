#ifndef TCC_9B_H
#define TCC_9B_H

void Clusters_Get9B_10B_11E_12D();

void Cluster_Write_9B();

#endif
