#ifndef TCC_8A_H
#define TCC_8A_H

void Clusters_Get8A();

void get_first_8A_type();

void get_second_8A_type();

void get_third_8A_type();

void Cluster_Write_8A(const int *trial);

#endif