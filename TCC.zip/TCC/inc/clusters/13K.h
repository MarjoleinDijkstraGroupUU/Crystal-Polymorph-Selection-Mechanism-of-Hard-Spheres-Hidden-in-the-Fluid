#ifndef TCC_13K_H
#define TCC_13K_H

int Clusters_Get13K(int sp3c_i, int sp3c_j, int the6A_i);

void Cluster_Write_13K();

#endif
