#ifndef TCC_10A_H
#define TCC_10A_H

void Clusters_Get10A();

void zero_used_array(int *used_sp4b);

void Cluster_Write_10A(int *first_sp4b_cluster, int *second_sp4b_cluster);

#endif
