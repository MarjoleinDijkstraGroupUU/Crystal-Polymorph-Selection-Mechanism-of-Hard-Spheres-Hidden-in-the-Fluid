#ifndef TCC_BCC9_H
#define TCC_BCC9_H

void Clusters_GetBCC_9();

void Cluster_Write_BCC9();

#endif
